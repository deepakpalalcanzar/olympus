# skipper example

a [Sails](http://sailsjs.org) application

## How to use

Start this example by running
```sh
$ node app
```

Then send a multipart form-data POST request to [http://localhost:1337/file/upload](http://localhost:1337/file/upload).  By default, uploaded file(s) will be uploaded to the app's `.tmp` folder.  We recommend using a tool like [POSTman](https://www.getpostman.com).