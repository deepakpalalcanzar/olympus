// TOTEST:

// 1. Duplicate text params
// 2. e.g. `avatar` => text param AND `avatar` => file param
// 3. File param w/ an empty file